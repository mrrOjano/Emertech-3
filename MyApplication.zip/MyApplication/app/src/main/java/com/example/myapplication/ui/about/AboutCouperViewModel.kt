package com.example.myapplication.ui.about

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class AboutCouperViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Here are all about the information of the app Couper"
    }
    val text: LiveData<String> = _text
}